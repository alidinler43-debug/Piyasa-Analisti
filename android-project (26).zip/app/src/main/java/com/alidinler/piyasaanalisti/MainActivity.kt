package com.alidinler.piyasaanalisti

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var depo: SharedPreferences

    // Yapay zeka işleri tek sırada çalışır; ağ işleri ayrı havuzda
    private val yzIs = Executors.newSingleThreadExecutor()
    private val agIs = Executors.newFixedThreadPool(4)

    @Volatile private var motor: Engine? = null
    @Volatile private var istenenArka = ""
    @Volatile private var gercekArka = ""
    @Volatile private var indiriliyor = false
    private val indirmeDur = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        depo = getSharedPreferences("piyasa_analisti", Context.MODE_PRIVATE)

        web = WebView(this)
        web.setBackgroundColor(0xFF12192B.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.textZoom = 100
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                if (u.scheme == "http" || u.scheme == "https") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u))
                    } catch (e: Exception) {
                    }
                    return true
                }
                return false
            }
        }
        web.addJavascriptInterface(Kopru(), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    @Deprecated("Geri tuşu sayfa içinde yönetiliyor")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.geriTusu && window.geriTusu()) ? 'evet' : 'hayir'") { deger ->
            if (deger == null || !deger.contains("evet")) finish()
        }
    }

    override fun onDestroy() {
        try {
            motor?.close()
        } catch (t: Throwable) {
        }
        motor = null
        super.onDestroy()
    }

    private fun modelDosyasi(): File = File(getExternalFilesDir(null) ?: filesDir, "model.litertlm")

    private fun parcaDosyasi(): File = File(modelDosyasi().path + ".part")

    private fun jsCagir(fonk: String, vararg arg: Any) {
        val a = arg.joinToString(",") { if (it is String) JSONObject.quote(it) else it.toString() }
        val kod = "window.$fonk && window.$fonk($a)"
        runOnUiThread { web.evaluateJavascript(kod, null) }
    }

    private fun motorKur(arka: String): Engine {
        val ayar = EngineConfig(
            modelPath = modelDosyasi().absolutePath,
            backend = if (arka == "gpu") Backend.GPU() else Backend.CPU(),
            visionBackend = null,
            audioBackend = null,
            maxNumTokens = 4096,
            cacheDir = cacheDir.absolutePath,
        )
        val e = Engine(ayar)
        e.initialize()
        return e
    }

    // Model zaten istenen işlemciyle açıksa tekrar açmaz. GPU açılamazsa CPU'ya döner.
    private fun motorHazirla(arka: String) {
        if (motor != null && istenenArka == arka) return
        try {
            motor?.close()
        } catch (t: Throwable) {
        }
        motor = null
        if (!modelDosyasi().exists()) {
            throw IllegalStateException("Model dosyası bulunamadı. Ayarlar'dan modeli indir.")
        }
        try {
            motor = motorKur(arka)
            gercekArka = arka
        } catch (t: Throwable) {
            if (arka != "gpu") throw t
            motor = motorKur("cpu")
            gercekArka = "cpu"
        }
        istenenArka = arka
    }

    inner class Kopru {

        @JavascriptInterface
        fun load(anahtar: String): String = depo.getString(anahtar, "") ?: ""

        @JavascriptInterface
        fun save(anahtar: String, deger: String) {
            depo.edit().putString(anahtar, deger).apply()
        }

        // Haber akışı (RSS) gibi sayfaları indirir
        @JavascriptInterface
        fun get(id: String, adres: String) {
            agIs.execute {
                var durum = 0
                var metin: String
                try {
                    val c = URL(adres).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000
                    c.readTimeout = 30000
                    c.setRequestProperty(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36"
                    )
                    durum = c.responseCode
                    val akis = if (durum >= 400) c.errorStream else c.inputStream
                    metin = akis?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
                    c.disconnect()
                } catch (e: Exception) {
                    durum = 0
                    metin = "Bağlantı hatası: " + (e.message ?: e.toString())
                }
                jsCagir("__koprudenCevap", id, durum, metin)
            }
        }

        @JavascriptInterface
        fun modelDurumu(): String {
            val f = modelDosyasi()
            val p = parcaDosyasi()
            val klasor = getExternalFilesDir(null) ?: filesDir
            return JSONObject()
                .put("var", f.exists())
                .put("boyut", if (f.exists()) f.length() else 0L)
                .put("parca", if (p.exists()) p.length() else 0L)
                .put("indiriliyor", indiriliyor)
                .put("yuklu", motor != null)
                .put("arka", gercekArka)
                .put("bos", klasor.usableSpace)
                .toString()
        }

        // Modeli parça parça indirir; yarım kalırsa kaldığı yerden devam eder
        @JavascriptInterface
        fun modelIndir(adres: String) {
            if (indiriliyor) return
            indiriliyor = true
            indirmeDur.set(false)
            runOnUiThread { window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
            Thread {
                val parca = parcaDosyasi()
                var hata = ""
                try {
                    var mevcut = if (parca.exists()) parca.length() else 0L
                    val c = URL(adres).openConnection() as HttpURLConnection
                    c.connectTimeout = 30000
                    c.readTimeout = 60000
                    c.instanceFollowRedirects = true
                    if (mevcut > 0) c.setRequestProperty("Range", "bytes=$mevcut-")
                    val kod = c.responseCode
                    if (kod == 200) mevcut = 0L
                    if (kod != 200 && kod != 206) throw Exception("Sunucu cevabı: $kod")
                    val kalan = c.contentLengthLong
                    val toplam = if (kalan > 0) mevcut + kalan else -1L
                    c.inputStream.use { giris ->
                        FileOutputStream(parca, mevcut > 0).use { cikis ->
                            val tampon = ByteArray(1 shl 16)
                            var son = 0L
                            while (true) {
                                if (indirmeDur.get()) throw InterruptedException("durduruldu")
                                val n = giris.read(tampon)
                                if (n < 0) break
                                cikis.write(tampon, 0, n)
                                mevcut += n
                                val simdi = System.currentTimeMillis()
                                if (simdi - son > 500) {
                                    son = simdi
                                    jsCagir("__indirmeIlerleme", mevcut, toplam)
                                }
                            }
                        }
                    }
                    c.disconnect()
                    if (toplam > 0 && mevcut < toplam) throw Exception("İndirme yarım kaldı, tekrar dene.")
                    val hedef = modelDosyasi()
                    if (hedef.exists()) hedef.delete()
                    if (!parca.renameTo(hedef)) throw Exception("Dosya kaydedilemedi.")
                } catch (e: InterruptedException) {
                    hata = "durduruldu"
                } catch (e: Exception) {
                    hata = e.message ?: e.toString()
                }
                indiriliyor = false
                runOnUiThread { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
                jsCagir("__indirmeBitti", hata)
            }.start()
        }

        @JavascriptInterface
        fun indirmeyiDurdur() {
            indirmeDur.set(true)
        }

        @JavascriptInterface
        fun modelSil() {
            yzIs.execute {
                try {
                    motor?.close()
                } catch (t: Throwable) {
                }
                motor = null
                istenenArka = ""
                modelDosyasi().delete()
                parcaDosyasi().delete()
                jsCagir("__modelSilindi")
            }
        }

        @JavascriptInterface
        fun modelYukle(id: String, arka: String) {
            yzIs.execute {
                try {
                    motorHazirla(arka)
                    jsCagir("__koprudenCevap", id, 200, gercekArka)
                } catch (t: Throwable) {
                    jsCagir("__koprudenCevap", id, 500, t.message ?: t.toString())
                }
            }
        }

        @JavascriptInterface
        fun uret(id: String, arka: String, sistem: String, mesaj: String) {
            yzIs.execute {
                try {
                    motorHazirla(arka)
                    val e = motor ?: throw IllegalStateException("Model açılamadı.")
                    val ayar = ConversationConfig(
                        systemInstruction = Contents.of(sistem),
                        samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = 0.3),
                    )
                    val cevap = e.createConversation(ayar).use { k -> k.sendMessage(mesaj).toString() }
                    jsCagir("__koprudenCevap", id, 200, cevap)
                } catch (t: Throwable) {
                    jsCagir("__koprudenCevap", id, 500, t.message ?: t.toString())
                }
            }
        }
    }
}
