package com.alidinler.piyasaanalisti;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

public class MainActivity extends Activity {

    private WebView web;
    private SharedPreferences depo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        depo = getSharedPreferences("piyasa_analisti", Context.MODE_PRIVATE);

        web = new WebView(this);
        web.setBackgroundColor(0xFF12192B);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String sema = u.getScheme();
                if ("http".equals(sema) || "https".equals(sema)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {
                    }
                    return true;
                }
                return false;
            }
        });

        web.addJavascriptInterface(new Kopru(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.geriTusu && window.geriTusu()) ? 'evet' : 'hayir'", deger -> {
            if (deger == null || !deger.contains("evet")) {
                finish();
            }
        });
    }

    public class Kopru {

        @JavascriptInterface
        public String load(String anahtar) {
            return depo.getString(anahtar, "");
        }

        @JavascriptInterface
        public void save(String anahtar, String deger) {
            depo.edit().putString(anahtar, deger).apply();
        }

        @JavascriptInterface
        public void post(final String id, final String adres, final String basliklarJson, final String govde) {
            new Thread(() -> {
                int durum = 0;
                String metin = "";
                String bekle = "";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(adres).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(30000);
                    c.setReadTimeout(600000);
                    c.setDoOutput(true);
                    JSONObject b = new JSONObject(basliklarJson);
                    Iterator<String> it = b.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.setRequestProperty(k, b.getString(k));
                    }
                    byte[] cikti = govde.getBytes(StandardCharsets.UTF_8);
                    c.setFixedLengthStreamingMode(cikti.length);
                    try (OutputStream os = c.getOutputStream()) {
                        os.write(cikti);
                    }
                    durum = c.getResponseCode();
                    String ra = c.getHeaderField("retry-after");
                    if (ra != null) bekle = ra;
                    InputStream is = durum >= 400 ? c.getErrorStream() : c.getInputStream();
                    metin = (is == null) ? "" : hepsiniOku(is);
                } catch (Exception e) {
                    durum = 0;
                    metin = "Bağlantı hatası: " + e.getMessage();
                } finally {
                    if (c != null) c.disconnect();
                }
                final String js = "window.__koprudenCevap(" + JSONObject.quote(id) + "," + durum + ","
                        + JSONObject.quote(metin) + "," + JSONObject.quote(bekle) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }
    }

    private static String hepsiniOku(InputStream is) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] tampon = new byte[8192];
        int n;
        while ((n = is.read(tampon)) != -1) {
            bo.write(tampon, 0, n);
        }
        is.close();
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }
}
